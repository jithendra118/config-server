package com.nooble.config;

import javax.servlet.http.HttpServletRequest;

import com.netflix.zuul.ZuulFilter;
import com.netflix.zuul.context.RequestContext;

import ch.qos.logback.core.net.SyslogOutputStream;

public class PreFilter extends ZuulFilter {


    public static final String AUTHORIZATION_HEADER = "Authorization";

    public String filterType() {
        return "pre";
    }

    public int filterOrder() {
        return 1;
    }

    public boolean shouldFilter() {
        return true;
    }

    public Object run() {
    	/*System.out.println("enterd into filter");
        RequestContext ctx = RequestContext.getCurrentContext();
        String authorizationValue = ctx.getRequest().getHeaders(AUTHORIZATION_HEADER).nextElement();
        ctx.addZuulRequestHeader(AUTHORIZATION_HEADER, authorizationValue);*/
        return null;
    }
}